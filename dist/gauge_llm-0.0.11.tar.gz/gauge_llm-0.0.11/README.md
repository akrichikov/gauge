# gauge
Evaluate LLMs with (bigger, smarter) LLMs
